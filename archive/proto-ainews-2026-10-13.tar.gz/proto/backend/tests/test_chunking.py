from app.rag.chunking import chunk_article, load_articles

ARTICLE = {
    "id": "a99", "title": "T", "source": "Chip Report", "date": "2026-09-01", "topic": "hardware",
    "url": "https://chipreport.example/x",
    "body": "\n\n".join(["Para one. " * 20, "Para two. " * 20, "Short three.", "Long. " * 200]),
}


def test_r1_chunks_are_at_most_600_chars():
    chunks = chunk_article(ARTICLE)
    assert chunks
    assert all(len(c.text) <= 600 for c in chunks)


def test_r1_splits_at_paragraph_boundaries():
    chunks = chunk_article(ARTICLE)
    # Paragraph one (200 chars) and two (200 chars) fit together; no chunk starts mid-paragraph for them.
    assert chunks[0].text.startswith("Para one.")
    assert "Para two." in chunks[0].text
    assert "Short three." in chunks[0].text or chunks[1].text.startswith("Short three.")


def test_r1_chunks_carry_metadata_and_ids():
    chunks = chunk_article(ARTICLE)
    for i, c in enumerate(chunks):
        assert c.chunk_id == f"a99#{i}"
        assert (c.article_id, c.source, c.date, c.topic, c.title, c.url) == (
            "a99", "Chip Report", "2026-09-01", "hardware", "T", "https://chipreport.example/x")


def test_r1_fixture_articles_load():
    articles = load_articles()
    assert len(articles) == 20
    assert {a["source"] for a in articles} == {"Frontier Notes", "Open Weights Digest", "Policy Wire", "Chip Report"}
