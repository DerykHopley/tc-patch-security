import { useEffect, useState } from "react";
import { ApiError, chat, examples as fetchExamples, health, type Example, type Health, type Turn } from "./api";
import { Chat, type Message } from "./components/Chat";
import { QueryPanel } from "./components/QueryPanel";
import { SourcesPanel } from "./components/SourcesPanel";
import { ToolCallCard } from "./components/ToolCallCard";

// The backend accepts at most 10 history turns of 2000 characters each (V1).
const MAX_TURNS = 10;
const MAX_TURN_CHARS = 2000;

// U9: the last 10 turns that really happened. A failed request and the question that caused it are left out.
function toHistory(messages: Message[]): Turn[] {
  return messages
    .filter((m, i) => !m.error && !messages[i + 1]?.error)
    .slice(-MAX_TURNS)
    .map((m) => ({ role: m.role, content: m.content.slice(0, MAX_TURN_CHARS) }));
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [examples, setExamples] = useState<Example[]>([]);
  const [status, setStatus] = useState<Health | null>(null);
  const [pending, setPending] = useState(false);
  const [selected, setSelected] = useState<number | null>(null);

  useEffect(() => {
    fetchExamples().then(setExamples).catch(() => setExamples([]));
    health().then(setStatus).catch(() => setStatus(null));
  }, []);

  async function send(text: string) {
    const history = toHistory(messages);
    const answerIndex = messages.length + 1; // after the user message added below
    setMessages((ms) => [...ms, { role: "user", content: text }]);
    setPending(true);
    try {
      const reply = await chat(text, history);
      setMessages((ms) => [...ms, { role: "assistant", content: reply.answer, reply }]);
      setSelected(answerIndex);
    } catch (e) {
      const message = e instanceof ApiError ? e.message : "Something went wrong. Try again.";
      setMessages((ms) => [...ms, { role: "assistant", content: "", error: message }]);
    } finally {
      setPending(false);
    }
  }

  function newChat() {
    setMessages([]);
    setSelected(null);
  }

  const reply = selected !== null ? messages[selected]?.reply : undefined;

  return (
    <div className="app">
      <header className="top">
        <h1>AI-news chatbot <span className="muted">prototype</span></h1>
        <span className={`chip ${status ? "" : "warn"}`}>
          {status ? `LLM: ${status.llm}` : "backend offline"}
        </span>
        <button type="button" onClick={newChat} disabled={pending || messages.length === 0}>New chat</button>
      </header>

      <main className="layout">
        <Chat
          messages={messages}
          examples={examples}
          pending={pending}
          selected={selected}
          onSend={send}
          onSelect={setSelected}
        />
        <aside className="details">
          {reply ? (
            <>
              {reply.query && <QueryPanel query={reply.query} />}
              {reply.tool_calls.length > 0 && (
                <section className="panel">
                  <h2>Tool calls</h2>
                  {reply.tool_calls.map((c) => <ToolCallCard key={c.id} call={c} />)}
                </section>
              )}
              <SourcesPanel sources={reply.sources} />
            </>
          ) : (
            <p className="muted">Sources, tool calls and the query plan for an answer show here.</p>
          )}
        </aside>
      </main>
    </div>
  );
}
