"""Everything a request needs, built once at start-up. Tests build their own and swap parts."""
import json
from dataclasses import dataclass

from app.config import FIXTURES, Settings
from app.llm.base import LLM
from app.rag.chunking import chunk_article, load_articles
from app.rag.embed import HashEmbedder
from app.rag.index import VectorIndex


@dataclass
class Deps:
    settings: Settings
    llm: LLM
    index: VectorIndex
    models: list[dict]
    pages: dict[str, str]  # url -> file name in fixtures/pages


def make_llm(settings: Settings) -> LLM:
    settings.check()
    if settings.llm_provider == "openrouter":
        from app.llm.openrouter import OpenRouterLLM

        return OpenRouterLLM(settings.openrouter_api_key, settings.openrouter_model)
    from app.llm.fake import FakeLLM

    return FakeLLM()


def build_deps(settings: Settings, llm: LLM | None = None) -> Deps:
    chunks = [c for a in load_articles() for c in chunk_article(a)]
    pages = json.loads((FIXTURES / "pages.json").read_text())
    pages.pop("_fixture_note", None)
    return Deps(
        settings=settings,
        llm=llm or make_llm(settings),
        index=VectorIndex(chunks, HashEmbedder()),
        models=json.loads((FIXTURES / "models.json").read_text())["data"],
        pages=pages,
    )
