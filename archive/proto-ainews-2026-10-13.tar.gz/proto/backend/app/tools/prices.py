"""compare_model_prices (T2): reads fixtures/models.json, shaped like OpenRouter's models API."""
import re
from typing import Annotated

from pydantic import BaseModel, Field, StringConstraints

from app.tools.registry import ToolSpec, register

Fragment = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=100)]


class PriceArgs(BaseModel):
    models: list[Fragment] = Field(min_length=1, max_length=5)


def _words(text: str) -> set[str]:
    return set(re.findall(r"[a-z0-9.]+", text.lower()))


def _matches(fragment: str, model: dict) -> bool:
    # Every word of the fragment must appear in the id or name: "claude sonnet" matches
    # "anthropic/claude-sonnet-4.5". Also allow a plain substring, so "gpt-5" works.
    haystack = f"{model['id']} {model['name']}".lower()
    return fragment.lower() in haystack or _words(fragment) <= _words(re.sub(r"[-/:]", " ", haystack))


def run(args: PriceArgs, deps, ctx) -> dict:
    found, not_found = [], []
    for frag in args.models:
        hits = [m for m in deps.models if _matches(frag, m)]
        if not hits:
            not_found.append(frag)
        for m in hits:
            if m["id"] not in {f["id"] for f in found}:
                found.append({
                    "id": m["id"],
                    "name": m["name"],
                    "context_length": m["context_length"],
                    "input_per_1m": round(float(m["pricing"]["prompt"]) * 1_000_000, 4),
                    "output_per_1m": round(float(m["pricing"]["completion"]) * 1_000_000, 4),
                })
    cheapest = min(found, key=lambda m: (m["input_per_1m"], m["output_per_1m"]))["id"] if found else None
    return {
        "models": found,
        "cheapest": cheapest,
        "cheapest_by": "input price, then output price",
        "not_found": not_found,
        "note": "Fixture data with invented prices, not live OpenRouter prices.",
    }


register(ToolSpec(
    name="compare_model_prices",
    description="Compare LLM prices per 1M input and output tokens and context length. Give 1-5 model ids or name fragments.",
    args_model=PriceArgs,
    run=run,
))
