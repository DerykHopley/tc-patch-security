import { useEffect, useRef, useState, type FormEvent, type KeyboardEvent } from "react";
import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import type { ChatReply, Example } from "../api";
import { UsageLine } from "./UsageLine";

export interface Message {
  role: "user" | "assistant";
  content: string;
  reply?: ChatReply; // assistant answers only
  error?: string; // set when the request failed (U7); not sent back as history
}

interface Props {
  messages: Message[];
  examples: Example[];
  pending: boolean;
  selected: number | null;
  onSend: (text: string) => void;
  onSelect: (index: number) => void;
}

// Turn "[2]" into a link to source 2, unless it's already a Markdown link. R6, U4.
const linkCitations = (text: string) => text.replace(/\[(\d+)\](?!\()/g, "[[$1]](#source-$1)");

// U1–U3, U7, U8: the message list, example buttons, input box and spinner.
export function Chat({ messages, examples, pending, selected, onSend, onSelect }: Props) {
  const [draft, setDraft] = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length, pending]);

  const canSend = draft.trim().length > 0 && !pending;

  function submit(e?: FormEvent) {
    e?.preventDefault();
    if (!canSend) return;
    onSend(draft.trim());
    setDraft("");
  }

  function onKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    // Enter sends, Shift+Enter adds a line.
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  }

  // A citation in an older answer first selects that answer, so its sources are the ones on screen.
  function openCitation(index: number, href: string) {
    onSelect(index);
    requestAnimationFrame(() => document.querySelector(href)?.scrollIntoView({ behavior: "smooth", block: "center" }));
  }

  return (
    <section className="chat">
      <div className="messages">
        {messages.length === 0 && (
          <p className="muted intro">Ask about AI news, model prices, or paste an article link.</p>
        )}
        {messages.map((m, i) => (
          <div
            key={i}
            className={`message ${m.role}${m.error ? " error" : ""}${i === selected ? " selected" : ""}`}
            onClick={m.reply ? () => onSelect(i) : undefined}
          >
            {m.error ? (
              <p>{m.error}</p>
            ) : m.role === "assistant" ? (
              <Markdown
                remarkPlugins={[remarkGfm]}
                components={{
                  a: ({ href = "", children }) =>
                    href.startsWith("#source-") ? (
                      <a href={href} className="cite" onClick={(e) => { e.preventDefault(); openCitation(i, href); }}>
                        {children}
                      </a>
                    ) : (
                      <a href={href} target="_blank" rel="noreferrer">{children}</a>
                    ),
                }}
              >
                {linkCitations(m.content)}
              </Markdown>
            ) : (
              <p>{m.content}</p>
            )}
            {m.reply && <UsageLine usage={m.reply.usage} steps={m.reply.steps} />}
          </div>
        ))}
        {pending && (
          <div className="message assistant thinking" role="status">
            <span className="spinner" aria-hidden="true" /> Thinking…
          </div>
        )}
        <div ref={endRef} />
      </div>

      {examples.length > 0 && (
        <div className="examples">
          {examples.map((ex) => (
            <button key={ex.id} type="button" disabled={pending} onClick={() => onSend(ex.question)} title={ex.id}>
              {ex.question}
            </button>
          ))}
        </div>
      )}

      <form className="composer" onSubmit={submit}>
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder="Ask a question…"
          rows={2}
          maxLength={1000}
          aria-label="Message"
        />
        <button type="submit" disabled={!canSend}>Send</button>
      </form>
    </section>
  );
}
