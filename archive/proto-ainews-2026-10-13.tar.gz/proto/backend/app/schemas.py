"""API request and reply shapes (A1, A2)."""
from typing import Literal

from pydantic import BaseModel, Field


class Turn(BaseModel):
    role: str  # checked in guard.check_message, so the error message is plain (V1)
    content: str


class ChatRequest(BaseModel):
    message: str
    history: list[Turn] = Field(default_factory=list)


class Source(BaseModel):
    n: int
    chunk_id: str
    article_id: str
    title: str
    source: str
    date: str
    topic: str
    url: str
    snippet: str
    score: float


class QueryInfo(BaseModel):
    original: str
    semantic_query: str
    rewrites: list[str]
    filters: dict[str, str]
    dropped_filters: list[str]
    relaxed: bool


class ToolCallRecord(BaseModel):
    id: str
    name: str
    args: dict
    status: Literal["ok", "error"]
    result: dict | None = None
    error: dict | None = None  # {code, message}
    duration_ms: float


class Usage(BaseModel):
    input_tokens: int = 0
    output_tokens: int = 0
    llm_calls: int = 0
    estimated: bool = False


class ChatReply(BaseModel):
    answer: str
    sources: list[Source]
    tool_calls: list[ToolCallRecord]
    query: QueryInfo | None
    usage: Usage
    steps: int
