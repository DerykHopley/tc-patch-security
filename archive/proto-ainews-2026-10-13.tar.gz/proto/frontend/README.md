# Prototype frontend

React + TypeScript (Vite) chat UI for the factory prototype. Built in stage 3 from [SPEC.md](../SPEC.md) (U1–U9) and the backend API.

```bash
npm install
npm run dev        # http://localhost:5173, talks to VITE_API_URL (default http://localhost:8000)
npm run build      # type-check + production build
npm run lint
```

If port 8000 is taken, run the backend on another port and point the UI at it:

```bash
cd ../backend && uv run uvicorn app.main:app --port 8001
cd ../frontend && VITE_API_URL=http://localhost:8001 npm run dev
```

The backend's CORS only allows `localhost:5173` (A5), so keep Vite on that port.

## Files

- `src/api.ts`: typed `chat()`, `examples()`, `health()`. Types written by hand from `backend/app/schemas.py`. `ApiError` turns `{error: {code, message}}` and network failures into a readable message (U7).
- `src/App.tsx`: message state, history (last 10 turns, U9), and the side panels for the selected answer.
- `src/components/Chat.tsx`: messages, example buttons, input, spinner (U1–U3). Answers are rendered as Markdown, and `[n]` becomes a link to source n.
- `QueryPanel`, `ToolCallCard` (price table for `compare_model_prices`), `SourcesPanel`, `UsageLine`: U4–U6, U8.

## Where things differ from PLAN.md

- **Markdown rendering with `react-markdown` + `remark-gfm`.** The answers contain tables and bold text. These libraries only render Markdown and add no styling, so the plan's "no UI library, plain CSS" still holds.
- **Any answer can drive the side panels.** Click an answer, or one of its `[n]` citations, to see its sources and tool calls. The newest answer is selected by default.
- **History leaves out failed requests.** An error message and the question that caused it are not sent back, so a refused injection doesn't follow the conversation around.

## Checked (2026-10-12, stage 3)

Headless Firefox (Playwright), FakeLLM backend, all 8 example questions clicked in order. Checked, not unit-tested:

- U1: Send is disabled for empty input. Enter sends.
- U2–U6: every example gets an answer. Q1 and Q5 show the query panel and sources; Q2 and Q5 show the price table; Q8 shows a red error card.
- U7: an injection message shows the backend's `prompt_injection` message in the chat.
- U8: usage under every answer, marked "estimated".
- U9: history sent grew 0, 2, 4 … 10, then stayed at 10. Q4 ("save that article") worked from history. New chat clears the list.
- R5 nonsense question: "I found nothing relevant", no sources.
- No console errors. The layout stacks at phone width.

Screenshots are in `screenshots/`.

## Not checked

- No frontend tests in the suite. The checks above were a one-off script.
- Long waits: FakeLLM answers in milliseconds, so the spinner was only seen briefly.
- `LLM_PROVIDER=openrouter`: real answers may format citations or tables differently.
