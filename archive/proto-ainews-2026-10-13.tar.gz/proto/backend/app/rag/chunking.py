"""Split articles into chunks of at most MAX_CHARS, at paragraph boundaries where possible (R1)."""
import json
import re
from dataclasses import dataclass

from app.config import FIXTURES

MAX_CHARS = 600


@dataclass(frozen=True)
class Chunk:
    chunk_id: str
    article_id: str
    title: str
    source: str
    date: str
    topic: str
    url: str
    text: str


def load_articles() -> list[dict]:
    return json.loads((FIXTURES / "articles.json").read_text())["articles"]


def _split_long(text: str, limit: int) -> list[str]:
    """A paragraph over the limit: split at sentence ends, then hard-split as a last resort."""
    parts, current = [], ""
    for sentence in re.split(r"(?<=[.!?])\s+", text):
        while len(sentence) > limit:
            if current:
                parts.append(current)
                current = ""
            parts.append(sentence[:limit])
            sentence = sentence[limit:].lstrip()
        if not sentence:
            continue
        candidate = f"{current} {sentence}" if current else sentence
        if len(candidate) <= limit:
            current = candidate
        else:
            parts.append(current)
            current = sentence
    if current:
        parts.append(current)
    return parts


def _pieces(body: str, limit: int) -> list[str]:
    paragraphs = [p.strip() for p in body.split("\n\n") if p.strip()]
    pieces, current = [], ""
    for p in paragraphs:
        for part in _split_long(p, limit) if len(p) > limit else [p]:
            candidate = f"{current}\n\n{part}" if current else part
            if len(candidate) <= limit:
                current = candidate
            else:
                pieces.append(current)
                current = part
    if current:
        pieces.append(current)
    return pieces


def chunk_article(article: dict, limit: int = MAX_CHARS) -> list[Chunk]:
    return [
        Chunk(
            chunk_id=f"{article['id']}#{i}",
            article_id=article["id"],
            title=article["title"],
            source=article["source"],
            date=article["date"],
            topic=article["topic"],
            url=article["url"],
            text=text,
        )
        for i, text in enumerate(_pieces(article["body"], limit))
    ]
