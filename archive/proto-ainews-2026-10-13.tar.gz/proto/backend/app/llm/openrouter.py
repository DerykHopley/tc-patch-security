"""OpenRouterLLM: the openai SDK pointed at OpenRouter (L2). Not in the test suite; checked by hand once."""
import json

import openai

from app import guard
from app.errors import LLMError
from app.llm.base import LLMReply, QueryPlan, ToolCall

TRANSLATE_PROMPT = f"""You turn a question about AI news into a search plan. Reply with JSON only:
{{"semantic_query": "...", "rewrites": ["...", "...", "..."], "filters": {{}}}}
- semantic_query: the topic of the question, without source names or dates.
- rewrites: 3 different phrasings of the search, using words a news article would use.
- filters (all optional): "source" (one of {guard.SOURCES}), "topic" (one of {guard.TOPICS}),
  "date_from" and "date_to" (YYYY-MM-DD). Only set a filter the question clearly asks for."""


class OpenRouterLLM:
    name = "openrouter"

    def __init__(self, api_key: str, model: str):
        self.model = model
        self.client = openai.OpenAI(api_key=api_key, base_url="https://openrouter.ai/api/v1", timeout=60)

    def _create(self, **kwargs):
        try:
            return self.client.chat.completions.create(model=self.model, **kwargs)
        except openai.OpenAIError as e:
            raise LLMError(f"OpenRouter request failed: {type(e).__name__}") from e

    @staticmethod
    def _usage(resp) -> tuple[int, int]:
        u = resp.usage
        return (u.prompt_tokens, u.completion_tokens) if u else (0, 0)

    def translate(self, question: str) -> tuple[QueryPlan, LLMReply]:
        resp = self._create(
            messages=[{"role": "system", "content": TRANSLATE_PROMPT}, {"role": "user", "content": question}],
            response_format={"type": "json_object"},
        )
        raw = resp.choices[0].message.content or ""
        try:
            data = json.loads(raw)
            plan = QueryPlan(
                semantic_query=str(data.get("semantic_query") or question),
                rewrites=[str(r) for r in (data.get("rewrites") or [])][:3],
                filters={k: str(v) for k, v in (data.get("filters") or {}).items() if v},
            )
        except (json.JSONDecodeError, AttributeError, TypeError):
            # A bad plan shouldn't fail the chat: fall back to searching the question as is.
            plan = QueryPlan(semantic_query=question)
        n_in, n_out = self._usage(resp)
        return plan, LLMReply(input_tokens=n_in, output_tokens=n_out)

    def step(self, messages: list[dict], tools: list[dict]) -> LLMReply:
        resp = self._create(messages=messages, tools=tools)
        msg = resp.choices[0].message
        calls = []
        for tc in msg.tool_calls or []:
            try:
                args = json.loads(tc.function.arguments or "{}")
            except json.JSONDecodeError:
                args = {"_unparsed": tc.function.arguments}  # run_tool turns this into a bad_arguments error
            calls.append(ToolCall(id=tc.id, name=tc.function.name, args=args if isinstance(args, dict) else {}))
        n_in, n_out = self._usage(resp)
        return LLMReply(content=msg.content, tool_calls=calls, input_tokens=n_in, output_tokens=n_out)
