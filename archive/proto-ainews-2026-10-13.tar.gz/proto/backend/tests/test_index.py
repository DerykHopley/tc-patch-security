from app.rag.chunking import Chunk
from app.rag.embed import HashEmbedder
from app.rag.index import Filters, VectorIndex


def chunk(cid, text, source="Chip Report", date="2026-09-01", topic="hardware"):
    return Chunk(chunk_id=f"{cid}#0", article_id=cid, title=cid, source=source, date=date,
                 topic=topic, url="https://chipreport.example/" + cid, text=text)


CHUNKS = [
    chunk("a", "memory bandwidth limits token speed"),
    chunk("b", "memory chips", source="Policy Wire", date="2026-08-15", topic="policy"),
    chunk("c", "agents call tools in a loop", date="2026-10-01", topic="agents"),
]


def test_r3_results_sorted_by_score_with_scores():
    hits = VectorIndex(CHUNKS, HashEmbedder()).search("memory bandwidth", k=3)
    assert [h.chunk.chunk_id for h in hits][:2] == ["a#0", "b#0"]
    assert hits[0].score >= hits[1].score
    assert all(0 < h.score <= 1 for h in hits)


def test_r3_k_limits_results():
    assert len(VectorIndex(CHUNKS, HashEmbedder()).search("memory", k=1)) == 1


def test_s2_filters_by_source_and_topic():
    idx = VectorIndex(CHUNKS, HashEmbedder())
    hits = idx.search("memory", k=5, filters=Filters(source="Policy Wire"))
    assert [h.chunk.article_id for h in hits] == ["b"]
    assert idx.search("memory", k=5, filters=Filters(topic="agents")) == []


def test_s2_date_range_is_inclusive():
    idx = VectorIndex(CHUNKS, HashEmbedder())
    hits = idx.search("memory tools loop", k=5, filters=Filters(date_from="2026-09-01", date_to="2026-10-01"))
    assert {h.chunk.article_id for h in hits} == {"a", "c"}


def test_r5_no_shared_words_no_hits():
    assert VectorIndex(CHUNKS, HashEmbedder()).search("pasta recipe", k=5) == []
