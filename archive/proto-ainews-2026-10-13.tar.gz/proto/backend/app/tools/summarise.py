"""summarise_url (T3): allowlisted URLs only, fixture pages only. Extractive summary, no LLM call."""
import re
from typing import Annotated

from pydantic import BaseModel, StringConstraints

from app import guard
from app.config import FIXTURES
from app.errors import ToolError
from app.tools.registry import ToolSpec, register

MAX_SUMMARY = 600


class SummariseArgs(BaseModel):
    url: Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=500)]


def _summary(text: str, limit: int = MAX_SUMMARY) -> str:
    out = ""
    for sentence in re.split(r"(?<=[.!?])\s+", " ".join(text.split())):
        if len(out) + len(sentence) + 1 > limit:
            break
        out = f"{out} {sentence}".strip()
    return out or text[:limit]


def run(args: SummariseArgs, deps, ctx) -> dict:
    guard.check_url(args.url)  # V3
    file = deps.pages.get(args.url)
    if not file:
        raise ToolError("That page isn't in the prototype's fixture pages.", "page_not_found")
    title, _, body = (FIXTURES / "pages" / file).read_text().partition("\n")
    body, removed = guard.strip_injections(body)  # V5: page text is data, never instructions
    return {"url": args.url, "title": title.strip(), "summary": _summary(body), "removed_lines": removed}


register(ToolSpec(
    name="summarise_url",
    description="Summarise a web page. Only https links on the four news sites are allowed.",
    args_model=SummariseArgs,
    run=run,
))
