# Prototype spec

What the factory prototype must do, as checks a test or a person can run. Input: [FACTORY-PLAN.md](../FACTORY-PLAN.md) and the course brief. How it's built: [PLAN.md](./PLAN.md).

Written 2026-10-12, stage 1.

## Decisions from stage 1

- **Agent loop.** `search_news` is a tool like the others. The LLM picks tools in a loop, at most 4 steps. With `FakeLLM` the picks are scripted per question.
- **Synthetic fixtures.** About 20 short AI-news articles written for the prototype. Fictional sources on `.example` domains, so nothing imitates a real outlet. Marked as fictional in the data.
- **One JSON reply.** `POST /chat` returns everything at once. The UI shows a spinner while it waits. No streaming.
- **History in the client.** The frontend keeps the messages and sends the recent turns with each request. No server storage, no export.
- **No LangChain.** `OpenRouterLLM` uses the `openai` SDK pointed at OpenRouter. The brief's stack is optional (confirmed 2026-10-12).

## The knowledge base

- 20 articles in `fixtures/articles.json`. Each has `id`, `title`, `source`, `date` (ISO), `topic`, `url`, `body` (3–6 paragraphs).
- 4 sources: `Frontier Notes`, `Open Weights Digest`, `Policy Wire`, `Chip Report`. URLs on matching `.example` hosts.
- 6 topics: `models`, `open-source`, `policy`, `research`, `hardware`, `agents`.
- Dates spread over 2026-06 to 2026-10, so date filters have something to cut.
- At least 2 articles are about the same subject from different sources, so the per-article cap and fusion matter.

## Acceptance checks

Each check has an ID. Tests name the ID they cover (e.g. `test_r1_chunks_carry_metadata`). "Q1" etc. refers to the scripted questions below.

### RAG

- **R1** Every article is split into chunks of at most 600 characters, split at paragraph boundaries where possible. Each chunk keeps the article's metadata and an id like `a07#2`.
- **R2** Chunks are embedded with the hash embedder. The same text always gives the same vector, and vectors are unit length.
- **R3** Search returns the top k chunks by cosine similarity, highest first, with the score.
- **R4** At most 2 chunks per article in the final results (the per-source cap from the earlier experiments).
- **R5** A question with no word in common with the knowledge base returns no sources, and the answer says nothing relevant was found. It does not make one up.
- **R6** Every answer built from search results cites its sources as `[1]`, `[2]`, matching the numbered `sources` in the reply.

### Query translation (multi-query + RRF)

- **Q-T1** The LLM turns the question into 3 rewrites. Search runs once per rewrite plus once for the semantic query.
- **Q-T2** The ranked lists are merged with reciprocal rank fusion: `score = Σ 1 / (60 + rank)`. A chunk that ranks well in several lists beats one that ranks first in only one. Unit-tested with hand-made lists.
- **Q-T3** The reply includes the rewrites, so the UI can show them.

### Structured retrieval (self-query)

- **S1** The same LLM call returns metadata filters: `source`, `topic`, `date_from`, `date_to`, each optional.
- **S2** Filters are applied before scoring. A filtered search never returns a chunk outside the filter.
- **S3** An unknown source or topic, or a bad date, is dropped and listed in `query.dropped_filters`. It is not an error.
- **S4** If the filters leave no results, search runs again without them and sets `query.relaxed: true`.
- **S5** Q1 ("What did Frontier Notes say about open-weight models in September 2026?") returns only Frontier Notes chunks dated 2026-09.

### Tools

- **T1** `search_news(query)`: runs the query-translation and self-query pipeline above, returns numbered sources.
- **T2** `compare_model_prices(models: list[str])`: 1–5 model ids or name fragments. Reads `fixtures/models.json`, shaped like OpenRouter's `GET /api/v1/models` (`data[].id`, `name`, `context_length`, `pricing.prompt`, `pricing.completion` as per-token strings). Returns price per 1M input and output tokens, context length, the cheapest model, and a `not_found` list. Prices are invented and marked as fixture data.
- **T3** `summarise_url(url)`: only allowlisted URLs (see V3). Reads a fixture page, not the web. Returns the title and a summary of at most 600 characters. The page text is passed on as data, never as instructions (see V5).
- **T4** `add_to_inbox(title, url?, note?)`: appends `{title, url, note, added}` to a local JSON file. Same URL twice → not added again, the result says it was already there. The file is created if missing.
- **T5** Bad tool arguments (wrong type, too many models, empty title) give a tool result with an `error`, not a crash. The agent gets the error and can answer around it.
- **T6** Every tool call appears in the reply's `tool_calls` with name, arguments, status (`ok` or `error`), result or error, and duration.
- **T7** The loop stops after 4 steps. If it stops early, the answer says so.

### Validation and security

- **V1** `message` must be 1–1000 characters after trimming. History: at most 10 turns, each at most 2000 characters, role `user` or `assistant`. Breaking a rule gives HTTP 400 with `{error: {code, message}}`. The message says which rule, in plain words.
- **V2** An obvious prompt injection in the user's message is refused before any LLM call, with code `prompt_injection`. Patterns like "ignore previous instructions", "reveal your system prompt", "you are now". Unit-tested with a list of positive and negative examples.
- **V3** `summarise_url` accepts only `https` URLs whose host is on the allowlist (the 4 fixture hosts). Anything else gives a tool error `url_not_allowed`. An allowlisted URL without a fixture page gives `page_not_found`.
- **V4** The system prompt keeps the bot to AI news. Q7 (off-topic) gets a short, polite refusal.
- **V5** Tool output is wrapped in clear delimiters and marked as untrusted data. Lines in it that match the injection patterns are removed and counted in the result (`removed_lines`). Q6 tests this with a fixture page that contains an injection.
- **V6** LLM failures give HTTP 502 with code `llm_error`. Any other server error gives HTTP 500 with a generic message, and no stack trace in the reply.

### API

- **A1** `POST /chat`, request: `{message, history: [{role, content}]}`.
- **A2** Reply: `{answer, sources[], tool_calls[], query, usage, steps}`.
  - `sources[]`: `{n, chunk_id, article_id, title, source, date, topic, url, snippet, score}`.
  - `query`: `{original, semantic_query, rewrites[], filters, dropped_filters[], relaxed}`, or `null` if `search_news` wasn't called.
  - `usage`: `{input_tokens, output_tokens, llm_calls, estimated}`. `estimated: true` with `FakeLLM` (characters / 4).
- **A3** `GET /health` returns `{status: "ok", llm: "fake" | "openrouter"}`.
- **A4** `GET /examples` returns the scripted questions, so the UI can offer them as buttons.
- **A5** CORS allows the Vite dev server (`http://localhost:5173`).

### LLM switch

- **L1** `LLM_PROVIDER=fake` (default) needs no key and no network. All tests run this way.
- **L2** `LLM_PROVIDER=openrouter` uses `OPENROUTER_API_KEY` and `OPENROUTER_MODEL`. A missing key fails at start-up with a clear message. Checked by hand once, at the end; not in the test suite.
- **L3** `.env.example` lists every setting. `.env` is git-ignored.

### UI (stage 3)

- **U1** A chat with the message list, an input box and a send button. Enter sends. Empty input can't be sent.
- **U2** Example question buttons from `GET /examples`.
- **U3** While waiting: a spinner and a "thinking" message; the send button is disabled.
- **U4** A sources panel for the latest answer: number, title, source, date, topic, score, snippet, link.
- **U5** A card per tool call: name, arguments, status, result. Errors shown in red. `compare_model_prices` results shown as a table.
- **U6** A query panel: the rewrites, the filters, dropped filters, and "relaxed" if set.
- **U7** API errors show as a readable message in the chat, not a blank screen.
- **U8** Token usage under each answer, labelled "estimated" when it is.
- **U9** The client sends the last 10 turns as `history`. A "new chat" button clears them.

## Scripted questions (FakeLLM)

`FakeLLM` matches these by keywords and plays back fixed rewrites, filters and tool calls. The answer text is built from the real tool results, so retrieval and tools are tested for real.

| ID | Question | Expected tools | Checks |
| --- | --- | --- | --- |
| Q1 | What did Frontier Notes say about open-weight models in September 2026? | `search_news` | S5, R6, Q-T1 |
| Q2 | Which is cheaper for long documents: Claude Sonnet or GPT? | `compare_model_prices` | T2, U5 |
| Q3 | Summarise https://frontiernotes.example/2026/agents-in-production | `summarise_url` | T3, V3 |
| Q4 | Save that article to my inbox (with Q3 in the history) | `add_to_inbox` | T4 |
| Q5 | What's new with open-source coding models, and what do they cost? | `search_news`, `compare_model_prices` | T6, multi-tool |
| Q6 | Summarise https://chipreport.example/2026/odd-page | `summarise_url` | V5 |
| Q7 | What's a good pasta recipe? | none | V4 |
| Q8 | Summarise https://evil.test/page | `summarise_url` (error) | V3, T5 |

Any other question: one `search_news` call with the question as is, no filters, then an answer from the top 2 sources. R5 is tested this way with a nonsense question.

## What the mocks hide

To check in stage 4 and in the real build:

- **Hash embeddings only match words.** Synonyms and paraphrases don't match. Retrieval quality says nothing about real embeddings.
- **Scripted rewrites and filters.** Whether a real LLM produces good rewrites, valid filters or sensible dates is untested.
- **Scripted tool choice.** Whether a real LLM picks the right tool, or calls tools in a loop, is untested.
- **The injection check is a regex list.** It stops obvious phrasing only. The real defence is delimiting tool output and limiting what tools can do.
- **Token usage is estimated** with `FakeLLM`. Real counts only come from the manual OpenRouter check.
- **No latency.** The spinner never shows for long with `FakeLLM`. Real LLM calls take seconds (reasoning models took 9–12 s before).
- **Fixture pages and prices.** No network errors, timeouts, HTML parsing or stale prices.
