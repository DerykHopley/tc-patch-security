"""FastAPI app: routes, error handlers, CORS (A1–A5, V1, V2, V6)."""
import json
import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app import guard
from app.agent import answer
from app.config import FIXTURES, Settings
from app.deps import Deps, build_deps
from app.errors import InjectionError, InputError, LLMError
from app.schemas import ChatReply, ChatRequest

log = logging.getLogger(__name__)


def _error(status: int, code: str, message: str) -> JSONResponse:
    return JSONResponse(status_code=status, content={"error": {"code": code, "message": message}})


def create_app(deps: Deps | None = None) -> FastAPI:
    # Built at start-up, so a missing OpenRouter key fails here with a clear message (L2).
    deps = deps or build_deps(Settings.from_env())
    examples = [{"id": s["id"], "question": s["question"]}
                for s in json.loads((FIXTURES / "fake_script.json").read_text())["scripts"]]

    app = FastAPI(title="AI-news chatbot prototype")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
        allow_methods=["GET", "POST"],
        allow_headers=["Content-Type"],
    )

    @app.exception_handler(RequestValidationError)
    async def bad_request(request: Request, exc: RequestValidationError):
        problems = "; ".join(f"{'.'.join(map(str, e['loc'][1:])) or 'body'}: {e['msg']}" for e in exc.errors())
        return _error(400, "invalid_request", f"The request isn't in the expected shape. {problems}")

    @app.exception_handler(InputError)
    @app.exception_handler(InjectionError)
    async def input_error(request: Request, exc: InputError | InjectionError):
        return _error(400, exc.code, exc.message)

    @app.exception_handler(LLMError)
    async def llm_error(request: Request, exc: LLMError):
        log.warning("LLM error: %s", exc.message)
        return _error(502, "llm_error", "The language model didn't respond properly. Try again in a moment.")

    @app.exception_handler(Exception)
    async def internal_error(request: Request, exc: Exception):
        log.exception("unhandled error")  # stack trace in the server log only
        return _error(500, "internal_error", "Something went wrong on the server.")

    @app.get("/health")
    def health():
        return {"status": "ok", "llm": deps.llm.name}

    @app.get("/examples")
    def get_examples():
        return examples

    @app.post("/chat", response_model=ChatReply)
    def chat(req: ChatRequest):
        history = [t.model_dump() for t in req.history]
        message = guard.check_message(req.message, history)  # V1, V2: before any LLM call
        return answer(message, history, deps)

    return app


def __getattr__(name: str):
    # `uvicorn app.main:app` builds the app on first access, so importing this module in tests is free.
    if name == "app":
        globals()["app"] = create_app()
        return globals()["app"]
    raise AttributeError(name)
