"""A tiny in-memory vector index: a numpy matrix plus chunk metadata. No vector database."""
from dataclasses import dataclass

import numpy as np

from app.rag.chunking import Chunk
from app.rag.embed import Embedder

# Hash collisions give unrelated text tiny scores. Below this a hit counts as "no match" (R5).
MIN_SCORE = 0.05


@dataclass(frozen=True)
class Filters:
    source: str | None = None
    topic: str | None = None
    date_from: str | None = None  # ISO dates compare correctly as strings
    date_to: str | None = None

    def matches(self, c: Chunk) -> bool:
        return (
            (self.source is None or c.source == self.source)
            and (self.topic is None or c.topic == self.topic)
            and (self.date_from is None or c.date >= self.date_from)
            and (self.date_to is None or c.date <= self.date_to)
        )

    def is_empty(self) -> bool:
        return self == Filters()


@dataclass(frozen=True)
class Hit:
    chunk: Chunk
    score: float


class VectorIndex:
    def __init__(self, chunks: list[Chunk], embedder: Embedder):
        self.chunks = chunks
        self.embedder = embedder
        self.matrix = embedder.embed([f"{c.title}\n{c.text}" for c in chunks])

    def search(self, query: str, k: int = 10, filters: Filters | None = None) -> list[Hit]:
        # Filter first, then score only what's left (S2).
        rows = [i for i, c in enumerate(self.chunks) if filters is None or filters.matches(c)]
        if not rows:
            return []
        q = self.embedder.embed([query])[0]
        scores = self.matrix[rows] @ q
        order = np.argsort(-scores, kind="stable")[:k]
        return [Hit(self.chunks[rows[i]], float(scores[i])) for i in order if scores[i] >= MIN_SCORE]
