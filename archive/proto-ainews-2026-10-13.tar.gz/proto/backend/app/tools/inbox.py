"""add_to_inbox (T4): append to a local JSON file. Same URL twice is not added again."""
import datetime as dt
import json
from typing import Annotated

from pydantic import BaseModel, StringConstraints

from app.tools.registry import ToolSpec, register

Text = Annotated[str, StringConstraints(strip_whitespace=True, max_length=500)]


class InboxArgs(BaseModel):
    title: Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=300)]
    url: Text | None = None
    note: Text | None = None


def run(args: InboxArgs, deps, ctx) -> dict:
    path = deps.settings.inbox_path
    items = json.loads(path.read_text()) if path.exists() else []
    url = args.url or None
    if url and any(i.get("url") == url for i in items):
        return {"added": False, "message": f"'{args.title}' is already in your inbox.", "count": len(items)}
    items.append({"title": args.title, "url": url, "note": args.note or None,
                  "added": dt.datetime.now().isoformat(timespec="seconds")})
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(items, indent=2, ensure_ascii=False) + "\n")
    return {"added": True, "message": f"Added '{args.title}' to your inbox.", "count": len(items)}


register(ToolSpec(
    name="add_to_inbox",
    description="Save an article or note to the user's reading inbox.",
    args_model=InboxArgs,
    run=run,
))
