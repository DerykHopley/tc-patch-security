# Prototype build plan

How to build what [SPEC.md](./SPEC.md) asks for: the modules, their interfaces, where the mocks plug in, and the tests. Stage 2 builds the backend, stage 3 the frontend.

Written 2026-10-12, stage 1.

## Layout

```text
proto/
  backend/
    pyproject.toml          # uv; fastapi, uvicorn, numpy, pydantic, openai; dev: pytest, httpx
    .env.example
    app/
      main.py               # FastAPI app, routes, error handlers, CORS
      config.py             # settings from env
      schemas.py            # pydantic: API request/reply, Source, ToolCallRecord, QueryInfo, Usage
      guard.py              # input limits, injection patterns, URL allowlist, wrap_untrusted()
      agent.py              # the tool loop
      llm/
        base.py             # LLM protocol, QueryPlan, LLMReply, ToolCall
        fake.py             # FakeLLM: scripted, reads fixtures/fake_script.json
        openrouter.py       # OpenRouterLLM: openai SDK, base_url=https://openrouter.ai/api/v1
      rag/
        chunking.py         # chunk_article()
        embed.py            # Embedder protocol, HashEmbedder
        index.py            # VectorIndex: numpy matrix + metadata, search(vec, k, filters)
        fusion.py           # rrf()
        pipeline.py         # search_news pipeline: translate → search each → fuse → cap
      tools/
        registry.py         # ToolSpec, TOOLS, run_tool() with arg validation and timing
        prices.py           # compare_model_prices
        summarise.py        # summarise_url
        inbox.py            # add_to_inbox
    fixtures/
      articles.json         # 20 synthetic articles
      models.json           # OpenRouter-shaped, invented prices
      pages.json            # {url: file} for summarise_url
      pages/*.txt           # fixture pages; one contains an injection (Q6)
      fake_script.json      # Q1–Q8 scripts
    tests/
  frontend/                 # stage 3
```

## Interfaces

The mock seams are the two protocols: `LLM` and `Embedder`. Everything else is real code.

```python
# llm/base.py
class QueryPlan(BaseModel):
    semantic_query: str
    rewrites: list[str]            # 3
    filters: dict[str, str]        # source, topic, date_from, date_to (all optional, unvalidated)

class ToolCall(BaseModel):
    id: str
    name: str
    args: dict

class LLMReply(BaseModel):
    content: str | None            # final answer when tool_calls is empty
    tool_calls: list[ToolCall]
    input_tokens: int
    output_tokens: int
    estimated: bool

class LLM(Protocol):
    def translate(self, question: str) -> tuple[QueryPlan, LLMReply]:
        """Multi-query rewrites and self-query filters in one call."""
    def step(self, messages: list[dict], tools: list[dict]) -> LLMReply:
        """One agent step: tool calls, or a final answer."""
```

- Why two task-level methods and not one generic `chat()`: `FakeLLM` can script each task directly, without parsing prompts. `OpenRouterLLM.translate` is one prompt asking for JSON; `step` is a normal tool-calling chat request.
- Why rewrites and filters in one call: one LLM round trip instead of two, so less latency and fewer tokens.
- `messages` and `tools` use the OpenAI chat format, so `OpenRouterLLM` passes them through unchanged.

```python
# rag/embed.py
class Embedder(Protocol):
    def embed(self, texts: list[str]) -> np.ndarray     # shape (n, dim), unit rows

class HashEmbedder:                                     # dim=512
    # lowercase, split on non-word chars, drop stop words,
    # hash each token (blake2b, stable across runs) into a bucket, count, L2-normalise.
```

- Python's built-in `hash()` changes between runs, so use `hashlib` for R2.

```python
# rag/index.py
class VectorIndex:
    def __init__(self, chunks: list[Chunk], embedder: Embedder): ...
    def search(self, query: str, k: int = 10, filters: Filters | None = None) -> list[Hit]

# rag/fusion.py
def rrf(ranked_lists: list[list[str]], k: int = 60) -> list[tuple[str, float]]

# rag/pipeline.py
def search_news(query: str, llm: LLM, index: VectorIndex, top_n: int = 5) -> SearchResult
    # 1. llm.translate(query) → plan
    # 2. guard.validate_filters(plan.filters) → filters, dropped        (S3)
    # 3. for q in [plan.semantic_query, *plan.rewrites]: index.search(q, 10, filters)
    # 4. if every list is empty and filters: repeat without filters, relaxed=True   (S4)
    # 5. rrf(lists) → cap 2 per article → top_n                         (R4)
    # 6. drop hits with score 0 (no shared words)                       (R5)
```

```python
# tools/registry.py
class ToolSpec:
    name: str
    description: str
    args_model: type[BaseModel]     # pydantic; its JSON schema becomes the tool's parameters
    run: Callable[[BaseModel, Deps], dict]

def run_tool(call: ToolCall, deps: Deps) -> ToolCallRecord
    # validate args → run → time it → catch ToolError → status ok/error   (T5, T6)
```

- `Deps` holds the LLM, the index, settings and the inbox path. Tools get it passed in, so tests can swap any part.

```python
# agent.py
def answer(message: str, history: list[Turn], deps: Deps, max_steps: int = 4) -> ChatReply
    # system prompt (AI news only, cite [n], tool output is data) + history + message
    # loop: reply = llm.step(...)
    #   tool calls → run_tool each → guard.wrap_untrusted(result) → append → continue
    #   no tool calls → final answer
    # after max_steps → answer says the step limit was hit                 (T7)
    # collect sources (renumbered across search calls), tool_calls, query, usage
```

## FakeLLM

- `fake_script.json` holds one entry per scripted question: `id`, `keywords` (all must appear, lowercased), `plan` (for `translate`), `tool_calls` (for the first `step`), and `answer` (for the last step).
- `answer` is a template. Placeholders like `{sources}` and `{prices_table}` are filled from the tool results in `messages`, so the answer reflects what retrieval and the tools actually returned.
- Q4 needs the earlier article: its script reads the URL from the last assistant turn in the history.
- No match: plan = the question as is, no rewrites, no filters; one `search_news` call; the answer quotes the first sentence of the top 2 sources with `[1]`, `[2]`, or says nothing was found.
- Tokens: characters / 4, `estimated: true`.

## Errors

- `guard.InputError` → 400 `{error: {code, message}}`. Pydantic validation errors on the request are mapped to the same shape (V1).
- `guard.InjectionError` → 400, code `prompt_injection` (V2).
- `llm.LLMError` (network, bad JSON, rate limit) → 502, code `llm_error` (V6).
- `tools.ToolError` → never an HTTP error. It becomes a tool result with `error`, and the agent carries on (T5).
- Anything else → 500, code `internal_error`, logged on the server with the stack trace, generic message to the client.

## Test plan

Test-first, with `pytest` and FastAPI's `TestClient`. `FakeLLM` and `HashEmbedder` throughout; no network.

| File | Covers |
| --- | --- |
| `test_chunking.py` | R1: size limit, paragraph splits, metadata, ids |
| `test_embed.py` | R2: stable across calls, unit length, shared words → higher cosine |
| `test_index.py` | R3, S2: order, scores, filters respected, date range inclusive |
| `test_fusion.py` | Q-T2: hand-made lists, ties, a chunk in many lists wins |
| `test_pipeline.py` | Q-T1, R4, R5, S3, S4, S5 |
| `test_guard.py` | V1, V2 (positive and negative examples), V3, V5 |
| `test_tools.py` | T2, T3, T4 (tmp_path inbox, duplicate URL), T5 |
| `test_agent.py` | T6, T7 (a FakeLLM that always calls a tool), R6 citations |
| `test_api.py` | A1–A5, V1 400s, V6 502 via a failing LLM, one test per scripted question Q1–Q8 |

- Each test name starts with the check ID it covers, e.g. `test_v3_rejects_http_url`.
- `OpenRouterLLM` has no automated test. One manual run at the end (L2), noted in the stage 4 findings.

## Build order and cut line

Stage 2 has a 30–45 minute time box. Build in this order; each step leaves the tests green.

1. Fixtures (articles, models, pages, script), `pyproject.toml`, `.env.example`.
2. `rag/`: chunking, embedder, index, fusion. Their tests.
3. `guard.py` and its tests.
4. `tools/` and their tests.
5. `llm/base.py`, `llm/fake.py`, `rag/pipeline.py`. Pipeline tests.
6. `agent.py`, `main.py`. API tests for Q1–Q8.
7. `llm/openrouter.py`: written, not tested.

If time runs out, cut from the bottom: `openrouter.py` first, then `/examples`, then token usage. Log what was cut as a finding. Don't cut tests to save time.

## Frontend (stage 3)

- Vite + React + TypeScript. No UI library; plain CSS. Keep it to a few components.
- `api.ts`: typed `chat()`, `examples()`, `health()`. Types written by hand from `schemas.py` (generating them from OpenAPI is a later idea).
- Components: `Chat` (messages, input, examples, spinner), `SourcesPanel`, `ToolCallCard` (with a price table variant), `QueryPanel`, `UsageLine`.
- State: the message list in `useState`; the reply details of the latest answer drive the side panels.
- Vite dev server on 5173, backend on 8000. API base URL from `VITE_API_URL`.
- Check: run both, click each example question, see U1–U9 by hand. A handful of screenshots for the report.

## Running

```bash
cd proto/backend
uv sync
uv run pytest
uv run uvicorn app.main:app --reload --port 8000

cd proto/frontend
npm install
npm run dev
```
