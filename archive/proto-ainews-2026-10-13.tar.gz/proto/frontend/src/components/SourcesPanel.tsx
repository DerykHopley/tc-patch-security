import type { Source } from "../api";

// U4: the numbered sources behind the selected answer. Ids match the [n] links in the answer.
export function SourcesPanel({ sources }: { sources: Source[] }) {
  return (
    <section className="panel">
      <h2>Sources</h2>
      {sources.length === 0 ? (
        <p className="muted">No sources for this answer.</p>
      ) : (
        <ol className="sources">
          {sources.map((s) => (
            <li key={s.chunk_id} id={`source-${s.n}`} className="source">
              <div className="source-head">
                <span className="badge">{s.n}</span>
                <a href={s.url} target="_blank" rel="noreferrer">{s.title}</a>
              </div>
              <div className="meta">
                {s.source} · {s.date} · {s.topic} · score {s.score.toFixed(3)}
              </div>
              <p className="snippet">{s.snippet}</p>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}
