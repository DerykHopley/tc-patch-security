import type { ToolCallRecord } from "../api";

interface PriceRow {
  id: string;
  name: string;
  context_length: number;
  input_per_1m: number;
  output_per_1m: number;
}

interface PriceResult {
  models: PriceRow[];
  cheapest: string | null;
  cheapest_by?: string;
  not_found: string[];
  note?: string;
}

function isPriceResult(r: Record<string, unknown>): r is Record<string, unknown> & PriceResult {
  return Array.isArray(r.models) && Array.isArray(r.not_found);
}

// The compare_model_prices variant of the card (U5).
function PriceTable({ result }: { result: PriceResult }) {
  return (
    <>
      <table className="prices">
        <thead>
          <tr><th>Model</th><th>Input $/1M</th><th>Output $/1M</th><th>Context</th></tr>
        </thead>
        <tbody>
          {result.models.map((m) => (
            <tr key={m.id} className={m.id === result.cheapest ? "cheapest" : undefined}>
              <td title={m.name}>{m.id}</td>
              <td>{m.input_per_1m}</td>
              <td>{m.output_per_1m}</td>
              <td>{m.context_length.toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {result.cheapest && <p className="meta">Cheapest by {result.cheapest_by ?? "price"}: {result.cheapest}</p>}
      {result.not_found.length > 0 && <p className="meta">Not found: {result.not_found.join(", ")}</p>}
      {result.note && <p className="meta">{result.note}</p>}
    </>
  );
}

// U5, T6: one card per tool call with its name, arguments, status and result. Errors in red.
export function ToolCallCard({ call }: { call: ToolCallRecord }) {
  const showPrices = call.name === "compare_model_prices" && call.result && isPriceResult(call.result);
  return (
    <article className={`tool-card ${call.status}`}>
      <header>
        <code>{call.name}</code>
        <span className={`status ${call.status}`}>{call.status}</span>
        <span className="meta">{call.duration_ms.toFixed(1)} ms</span>
      </header>
      <pre className="args">{JSON.stringify(call.args, null, 2)}</pre>
      {call.error && (
        <p className="tool-error"><strong>{call.error.code}</strong>: {call.error.message}</p>
      )}
      {call.result && (showPrices
        ? <PriceTable result={call.result as unknown as PriceResult} />
        : (
          <details>
            <summary>Result</summary>
            <pre>{JSON.stringify(call.result, null, 2)}</pre>
          </details>
        ))}
    </article>
  );
}
