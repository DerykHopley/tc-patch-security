import json
import time

import pytest

from app.llm.base import ToolCall
from app.tools.registry import Context, run_tool


def call(deps, name, **args):
    return run_tool(ToolCall(id="t1", name=name, args=args), deps, Context())


# --- compare_model_prices (T2)

def test_t2_prices_per_million_and_cheapest(deps):
    rec = call(deps, "compare_model_prices", models=["claude sonnet", "gpt-5"])
    assert rec.status == "ok", rec.error
    by_id = {m["id"]: m for m in rec.result["models"]}
    assert by_id["anthropic/claude-sonnet-4.5"]["input_per_1m"] == pytest.approx(3.0)
    assert by_id["anthropic/claude-sonnet-4.5"]["output_per_1m"] == pytest.approx(15.0)
    assert by_id["anthropic/claude-sonnet-4.5"]["context_length"] == 1_000_000
    assert rec.result["cheapest"] == "openai/gpt-5-mini"
    assert rec.result["not_found"] == []
    assert "fixture" in rec.result["note"].lower()


def test_t2_not_found_listed(deps):
    rec = call(deps, "compare_model_prices", models=["kestrel", "no-such-model"])
    assert [m["id"] for m in rec.result["models"]] == ["northwind/kestrel-70b"]
    assert rec.result["not_found"] == ["no-such-model"]


@pytest.mark.parametrize("models", [[], ["a", "b", "c", "d", "e", "f"], "gpt", [1, 2]])
def test_t5_bad_price_args_give_error_not_crash(deps, models):
    rec = call(deps, "compare_model_prices", models=models)
    assert rec.status == "error"
    assert rec.error["code"] == "bad_arguments"


# --- summarise_url (T3, V3, V5)

def test_t3_summarises_fixture_page(deps):
    rec = call(deps, "summarise_url", url="https://frontiernotes.example/2026/agents-in-production")
    assert rec.status == "ok"
    assert rec.result["title"] == "Agents in production: what teams learned this year"
    assert 0 < len(rec.result["summary"]) <= 600
    assert rec.result["removed_lines"] == 0


def test_v3_url_not_allowed(deps):
    rec = call(deps, "summarise_url", url="https://evil.test/page")
    assert rec.status == "error"
    assert rec.error["code"] == "url_not_allowed"


def test_v3_page_not_found(deps):
    rec = call(deps, "summarise_url", url="https://policywire.example/nothing-here")
    assert rec.error["code"] == "page_not_found"


def test_v5_injection_lines_removed_from_page(deps):
    rec = call(deps, "summarise_url", url="https://chipreport.example/2026/odd-page")
    assert rec.status == "ok"
    assert rec.result["removed_lines"] == 2
    assert "ignore" not in rec.result["summary"].lower()
    assert "evil.test" not in rec.result["summary"]


# --- add_to_inbox (T4)

def test_t4_appends_and_creates_file(deps):
    rec = call(deps, "add_to_inbox", title="A", url="https://x.example/a", note="n")
    assert rec.status == "ok" and rec.result["added"] is True
    items = json.loads(deps.settings.inbox_path.read_text())
    assert items[0]["title"] == "A" and items[0]["url"] == "https://x.example/a" and items[0]["note"] == "n"
    assert "added" in items[0]


def test_t4_duplicate_url_not_added_twice(deps):
    call(deps, "add_to_inbox", title="A", url="https://x.example/a")
    rec = call(deps, "add_to_inbox", title="A again", url="https://x.example/a")
    assert rec.result["added"] is False
    assert "already" in rec.result["message"]
    assert len(json.loads(deps.settings.inbox_path.read_text())) == 1


def test_t4_no_url_is_fine(deps):
    assert call(deps, "add_to_inbox", title="Just a note").result["added"] is True


@pytest.mark.parametrize("args", [{"title": ""}, {"title": "   "}, {}, {"title": 5}])
def test_t5_bad_inbox_args(deps, args):
    rec = call(deps, "add_to_inbox", **args)
    assert rec.status == "error" and rec.error["code"] == "bad_arguments"


# --- registry (T5, T6)

def test_t5_unknown_tool(deps):
    rec = call(deps, "launch_rockets")
    assert rec.status == "error" and rec.error["code"] == "unknown_tool"


def test_t6_record_has_name_args_status_duration(deps):
    rec = call(deps, "compare_model_prices", models=["kestrel"])
    assert rec.name == "compare_model_prices"
    assert rec.args == {"models": ["kestrel"]}
    assert rec.duration_ms >= 0


def test_t5_unexpected_exception_in_tool_is_caught(deps, monkeypatch):
    from app.tools import registry

    def boom(args, deps, ctx):
        raise RuntimeError("disk on fire")

    monkeypatch.setattr(registry.TOOLS["compare_model_prices"], "run", boom)
    rec = call(deps, "compare_model_prices", models=["kestrel"])
    assert rec.status == "error" and rec.error["code"] == "tool_failed"
    assert "disk on fire" not in rec.error["message"]
