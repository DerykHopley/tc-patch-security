from app.llm.base import LLMReply, QueryPlan
from app.rag.pipeline import search_news


class PlanLLM:
    """Returns a fixed plan, to test the pipeline without the FakeLLM script."""

    def __init__(self, plan: QueryPlan):
        self.plan = plan

    def translate(self, question):
        return self.plan, LLMReply(content=None, tool_calls=[], input_tokens=1, output_tokens=1, estimated=True)


def plan(**kw):
    return QueryPlan(**({"semantic_query": "open-weight models", "rewrites": [], "filters": {}} | kw))


def test_qt1_searches_once_per_rewrite_plus_semantic(deps, monkeypatch):
    seen = []
    real = deps.index.search
    monkeypatch.setattr(deps.index, "search", lambda q, k=10, filters=None: seen.append(q) or real(q, k, filters))
    p = plan(rewrites=["one", "two", "three"])
    res = search_news("q", PlanLLM(p), deps.index)
    assert seen == ["open-weight models", "one", "two", "three"]
    assert res.query.rewrites == ["one", "two", "three"]
    assert res.query.original == "q"


def test_r4_at_most_two_chunks_per_article(deps):
    res = search_news("q", PlanLLM(plan(semantic_query="open-weight models open weights release licence")), deps.index,
                      top_n=20)
    counts = {}
    for s in res.sources:
        counts[s.article_id] = counts.get(s.article_id, 0) + 1
    assert counts and max(counts.values()) <= 2


def test_r5_nonsense_question_returns_no_sources(deps):
    res = search_news("q", PlanLLM(plan(semantic_query="zebra gazpacho trombone")), deps.index)
    assert res.sources == []


def test_s3_unknown_and_bad_filters_dropped(deps):
    p = plan(filters={"source": "Daily Bugle", "topic": "cooking", "date_from": "last tuesday", "date_to": "2026-09-30"})
    res = search_news("q", PlanLLM(p), deps.index)
    assert res.query.filters == {"date_to": "2026-09-30"}
    assert set(res.query.dropped_filters) == {"source=Daily Bugle", "topic=cooking", "date_from=last tuesday"}


def test_s4_relaxes_when_filters_empty_everything(deps):
    p = plan(filters={"topic": "hardware", "date_from": "2026-01-01", "date_to": "2026-01-31"})
    res = search_news("q", PlanLLM(p), deps.index)
    assert res.query.relaxed is True
    assert res.sources


def test_s5_q1_only_frontier_notes_in_september(deps):
    q = "What did Frontier Notes say about open-weight models in September 2026?"
    res = search_news(q, deps.llm, deps.index)
    assert res.sources
    assert all(s.source == "Frontier Notes" and s.date.startswith("2026-09") for s in res.sources)
    assert len(res.query.rewrites) == 3
    assert res.query.relaxed is False


def test_sources_numbered_from_start(deps):
    res = search_news("q", PlanLLM(plan()), deps.index, start_n=4)
    assert [s.n for s in res.sources] == list(range(4, 4 + len(res.sources)))
