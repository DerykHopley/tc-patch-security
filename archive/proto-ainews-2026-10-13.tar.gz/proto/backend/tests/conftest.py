import pytest


@pytest.fixture
def deps(tmp_path):
    """Real fixtures, FakeLLM, HashEmbedder, inbox in a temp folder."""
    from app.config import Settings
    from app.deps import build_deps

    return build_deps(Settings(llm_provider="fake", inbox_path=tmp_path / "inbox.json"))
