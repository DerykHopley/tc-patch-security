"""The search_news pipeline: translate → search each query → fuse → cap per article (T1)."""
from dataclasses import dataclass

from app import guard
from app.llm.base import LLM, LLMReply
from app.rag.fusion import rrf
from app.rag.index import Filters, Hit, VectorIndex
from app.schemas import QueryInfo, Source

PER_ARTICLE_CAP = 2  # R4
PER_QUERY_K = 10


@dataclass
class SearchResult:
    query: QueryInfo
    sources: list[Source]
    reply: LLMReply  # the translate call, for usage


def _search_all(index: VectorIndex, queries: list[str], filters: Filters) -> list[list[Hit]]:
    return [index.search(q, PER_QUERY_K, None if filters.is_empty() else filters) for q in queries]


def search_news(query: str, llm: LLM, index: VectorIndex, top_n: int = 5, start_n: int = 1) -> SearchResult:
    plan, reply = llm.translate(query)  # Q-T1, S1
    kept, dropped = guard.validate_filters(plan.filters)  # S3
    filters = Filters(**kept)
    queries = [plan.semantic_query, *plan.rewrites]

    lists = _search_all(index, queries, filters)
    relaxed = False
    if not any(lists) and not filters.is_empty():  # S4
        lists = _search_all(index, queries, Filters())
        relaxed = True

    best: dict[str, Hit] = {}
    for hits in lists:
        for h in hits:
            if h.chunk.chunk_id not in best or h.score > best[h.chunk.chunk_id].score:
                best[h.chunk.chunk_id] = h

    per_article: dict[str, int] = {}
    picked: list[Hit] = []
    for cid, _ in rrf([[h.chunk.chunk_id for h in hits] for hits in lists]):  # Q-T2
        hit = best[cid]
        if per_article.get(hit.chunk.article_id, 0) >= PER_ARTICLE_CAP:  # R4
            continue
        per_article[hit.chunk.article_id] = per_article.get(hit.chunk.article_id, 0) + 1
        picked.append(hit)
        if len(picked) == top_n:
            break

    sources = [
        Source(
            n=start_n + i, chunk_id=h.chunk.chunk_id, article_id=h.chunk.article_id, title=h.chunk.title,
            source=h.chunk.source, date=h.chunk.date, topic=h.chunk.topic, url=h.chunk.url,
            snippet=h.chunk.text[:300], score=round(h.score, 3),
        )
        for i, h in enumerate(picked)
    ]
    info = QueryInfo(
        original=query, semantic_query=plan.semantic_query, rewrites=plan.rewrites,
        filters=kept, dropped_filters=dropped, relaxed=relaxed,
    )
    return SearchResult(query=info, sources=sources, reply=reply)
