// Typed client for the backend. Types are written by hand from backend/app/schemas.py (A1, A2).

export const API_URL: string = import.meta.env.VITE_API_URL ?? "http://localhost:8000";

export type Role = "user" | "assistant";

export interface Turn {
  role: Role;
  content: string;
}

export interface Source {
  n: number;
  chunk_id: string;
  article_id: string;
  title: string;
  source: string;
  date: string;
  topic: string;
  url: string;
  snippet: string;
  score: number;
}

export interface QueryInfo {
  original: string;
  semantic_query: string;
  rewrites: string[];
  filters: Record<string, string>;
  dropped_filters: string[];
  relaxed: boolean;
}

export interface ToolError {
  code: string;
  message: string;
}

export interface ToolCallRecord {
  id: string;
  name: string;
  args: Record<string, unknown>;
  status: "ok" | "error";
  result: Record<string, unknown> | null;
  error: ToolError | null;
  duration_ms: number;
}

export interface Usage {
  input_tokens: number;
  output_tokens: number;
  llm_calls: number;
  estimated: boolean;
}

export interface ChatReply {
  answer: string;
  sources: Source[];
  tool_calls: ToolCallRecord[];
  query: QueryInfo | null;
  usage: Usage;
  steps: number;
}

export interface Example {
  id: string;
  question: string;
}

export interface Health {
  status: "ok";
  llm: "fake" | "openrouter";
}

/** An error from the API, or from not reaching it, with a message a person can read (U7). */
export class ApiError extends Error {
  readonly code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${API_URL}${path}`, init);
  } catch {
    throw new ApiError("network_error", `Can't reach the backend at ${API_URL}. Is it running?`);
  }
  const body: unknown = await res.json().catch(() => null);
  if (!res.ok) {
    // The backend sends {error: {code, message}} (V1, V6). Anything else gets a generic message.
    const err = (body as { error?: ToolError } | null)?.error;
    throw new ApiError(err?.code ?? `http_${res.status}`, err?.message ?? `The backend replied with HTTP ${res.status}.`);
  }
  return body as T;
}

export function chat(message: string, history: Turn[]): Promise<ChatReply> {
  return request<ChatReply>("/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message, history }),
  });
}

export const examples = () => request<Example[]>("/examples");
export const health = () => request<Health>("/health");
