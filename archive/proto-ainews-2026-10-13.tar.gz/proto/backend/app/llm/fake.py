"""FakeLLM: scripted, free, same every run (L1). Reads fixtures/fake_script.json.

Tool choice, rewrites and filters are scripted. The answer text is a template filled from the
real tool results in `messages`, so retrieval and tools are tested for real.
"""
import json
import re

from app import guard
from app.config import FIXTURES
from app.llm.base import LLMReply, QueryPlan, ToolCall

NOTHING_FOUND = "I found nothing relevant in the news archive for that question."


def _tokens(text: str) -> int:
    return max(1, len(text) // 4)  # estimate: characters / 4


def _first_sentence(text: str) -> str:
    return re.split(r"(?<=[.!?])\s", " ".join(text.split()), maxsplit=1)[0]


def _bullets(sources: list[dict], limit: int) -> str:
    if not sources:
        return NOTHING_FOUND
    return "\n".join(
        f"- **{s['title']}** ({s['source']}, {s['date']}): {_first_sentence(s['snippet'])} [{s['n']}]"
        for s in sources[:limit]
    )


def _prices_table(models: list[dict]) -> str:
    rows = ["| Model | Input $/1M | Output $/1M | Context |", "| --- | ---: | ---: | ---: |"]
    rows += [f"| {m['id']} | {m['input_per_1m']:g} | {m['output_per_1m']:g} | {m['context_length']:,} |" for m in models]
    return "\n".join(rows)


class FakeLLM:
    name = "fake"

    def __init__(self, script_path=FIXTURES / "fake_script.json"):
        self.scripts = json.loads(script_path.read_text())["scripts"]

    def examples(self) -> list[dict]:
        return [{"id": s["id"], "question": s["question"]} for s in self.scripts]

    def _match(self, text: str) -> dict | None:
        low = text.lower()
        for s in self.scripts:
            if all(k in low for k in s["keywords"]):
                return s
            # translate() gets the search_news query, which may not repeat every keyword (Q5).
            if any(tc["name"] == "search_news" and tc["args"]["query"].lower() == low.strip() for tc in s["tool_calls"]):
                return s
        return None

    def translate(self, question: str) -> tuple[QueryPlan, LLMReply]:
        script = self._match(question)
        if script and "plan" in script:
            plan = QueryPlan(**script["plan"])
        else:
            plan = QueryPlan(semantic_query=question, rewrites=[], filters={})
        reply = LLMReply(input_tokens=_tokens(question) + 100, output_tokens=_tokens(plan.model_dump_json()),
                         estimated=True)
        return plan, reply

    def step(self, messages: list[dict], tools: list[dict]) -> LLMReply:
        last_user = max(i for i, m in enumerate(messages) if m["role"] == "user")
        question = messages[last_user]["content"]
        script = self._match(question)
        tool_msgs = [m for m in messages[last_user:] if m["role"] == "tool"]
        n_input = _tokens(json.dumps(messages) + json.dumps(tools))

        if not tool_msgs:
            calls = script["tool_calls"] if script else [{"name": "search_news", "args": {"query": question}}]
            if calls:
                history = messages[:last_user]
                tool_calls = [ToolCall(id=f"call_{i}", name=c["name"], args=self._fill_args(c["args"], history))
                              for i, c in enumerate(calls)]
                return LLMReply(tool_calls=tool_calls, input_tokens=n_input,
                                output_tokens=_tokens(json.dumps([t.model_dump() for t in tool_calls])), estimated=True)

        content = self._answer(script, tool_msgs)
        return LLMReply(content=content, input_tokens=n_input, output_tokens=_tokens(content), estimated=True)

    @staticmethod
    def _fill_args(args: dict, history: list[dict]) -> dict:
        """Q4: "that article" means the last title and URL the assistant mentioned."""
        said = "\n".join(m.get("content") or "" for m in history if m["role"] == "assistant")
        titles = re.findall(r"\*\*(.+?)\*\*", said)
        urls = [u.rstrip(").,") for u in re.findall(r"https?://\S+", said)]
        values = {"last_title": titles[-1] if titles else "Saved article", "last_url": urls[-1] if urls else ""}
        return {k: v.format(**values) if isinstance(v, str) else v for k, v in args.items()}

    @staticmethod
    def _answer(script: dict | None, tool_msgs: list[dict]) -> str:
        fields: dict = {}
        sources: list[dict] = []
        for m in tool_msgs:
            data = json.loads(guard.unwrap(m["content"]))
            if "error" in data and isinstance(data["error"], dict):
                fields["error"] = data["error"]["message"]
            elif "sources" in data:
                sources += data["sources"]
            elif "models" in data:
                fields["prices_table"] = _prices_table(data["models"])
                fields["cheapest"] = data["cheapest"]
            elif "summary" in data:
                fields |= {k: data[k] for k in ("title", "url", "summary", "removed_lines")}
            elif "added" in data:
                fields["inbox_message"] = data["message"]

        if script is None:
            return f"From the news archive:\n\n{_bullets(sources, 2)}" if sources else NOTHING_FOUND
        fields["sources"] = _bullets(sources, 3)
        try:
            return script["answer"].format(**fields)
        except KeyError:
            return f"Sorry, a tool didn't give me what I needed: {fields.get('error', 'no result')}"
