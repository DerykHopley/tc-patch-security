"""search_news (T1): the query-translation and self-query pipeline as a tool."""
from typing import Annotated

from pydantic import BaseModel, StringConstraints

from app.rag.pipeline import search_news
from app.tools.registry import ToolSpec, register


class SearchArgs(BaseModel):
    query: Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=500)]


def run(args: SearchArgs, deps, ctx) -> dict:
    res = search_news(args.query, deps.llm, deps.index, start_n=len(ctx.sources) + 1)
    ctx.add_usage(res.reply)
    ctx.sources.extend(res.sources)
    ctx.query = res.query
    return {
        "query": res.query.model_dump(),
        "sources": [s.model_dump(include={"n", "title", "source", "date", "topic", "url", "snippet"}) for s in res.sources],
    }


register(ToolSpec(
    name="search_news",
    description="Search the AI-news archive. Returns numbered sources; cite them as [n].",
    args_model=SearchArgs,
    run=run,
))
