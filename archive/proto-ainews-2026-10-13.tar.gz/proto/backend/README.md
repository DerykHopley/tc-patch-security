# Prototype backend

FastAPI backend for the factory prototype. Built in stage 2 from [SPEC.md](../SPEC.md) and [PLAN.md](../PLAN.md).

```bash
uv sync
uv run pytest                                     # 104 tests, no key, no network
uv run uvicorn app.main:app --reload --port 8000  # FakeLLM
cp .env.example .env                              # then, for the real LLM:
uv run --env-file .env uvicorn app.main:app --port 8000
```

## Where things differ from PLAN.md

- **HashEmbedder uses 4096 dimensions, not 512.** With ~1,000 distinct words, 512 buckets collide often, so unrelated words still score above 0 and R5 breaks. The index also drops hits under a score of 0.05 (`MIN_SCORE`). Checked by the R5 tests.
- **Errors live in `app/errors.py`.** `guard`, `llm` and `tools` import them from there, so nothing imports in a circle.
- **`Context` in `tools/registry.py`.** It's per-request state: sources across search calls, so `[n]` numbers stay unique, plus the last query and the usage totals. `search_news` writes to it.
- **`summarise_url` is extractive.** It takes the first sentences up to 600 characters. There's no LLM call inside a tool.
- **`cheapest` means cheapest by input price** (then output price). The result says so in `cheapest_by`.
- **Fixtures add fictional models** (Larkspur Coder, Tidewater Code, Kestrel) to `models.json`, so Q5's price lookup matches the articles.

## Seen while building (for stage 4)

- Hash retrieval pulls in loose matches. "how much energy do data centres use?" returns the right article first, then an unrelated one on licences, which shares only one common word.
- `OpenRouterLLM` imports and fails fast without a key. It hasn't been run against the API yet (L2 is a manual check).
