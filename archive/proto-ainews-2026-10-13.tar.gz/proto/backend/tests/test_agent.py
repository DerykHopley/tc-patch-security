import re

from app.agent import answer
from app.llm.base import LLMReply, QueryPlan, ToolCall
from app.llm.fake import FakeLLM


class LoopingLLM(FakeLLM):
    """Always asks for another tool call: the agent must stop it (T7)."""

    def step(self, messages, tools):
        return LLMReply(tool_calls=[ToolCall(id="x", name="compare_model_prices", args={"models": ["kestrel"]})],
                        input_tokens=10, output_tokens=5, estimated=True)


def test_t7_loop_stops_after_max_steps(deps):
    deps.llm = LoopingLLM()
    reply = answer("compare prices forever", [], deps)
    assert reply.steps == 4
    assert len(reply.tool_calls) == 4
    assert "stopped after 4 steps" in reply.answer


def test_t6_every_tool_call_recorded(deps):
    reply = answer("What's new with open-source coding models, and what do they cost?", [], deps)
    assert [t.name for t in reply.tool_calls] == ["search_news", "compare_model_prices"]
    for t in reply.tool_calls:
        assert t.status == "ok" and t.result and t.duration_ms >= 0 and t.args


def test_r6_citations_match_numbered_sources(deps):
    reply = answer("What did Frontier Notes say about open-weight models in September 2026?", [], deps)
    cited = {int(n) for n in re.findall(r"\[(\d+)\]", reply.answer)}
    assert cited and cited <= {s.n for s in reply.sources}
    assert [s.n for s in reply.sources] == list(range(1, len(reply.sources) + 1))


def test_r5_nothing_found_does_not_make_things_up(deps):
    reply = answer("zebra gazpacho trombone", [], deps)
    assert reply.sources == []
    assert "nothing relevant" in reply.answer


def test_usage_adds_up_over_calls(deps):
    reply = answer("What did Frontier Notes say about open-weight models in September 2026?", [], deps)
    # translate + 2 steps (tool call, final answer)
    assert reply.usage.llm_calls == 3
    assert reply.usage.estimated is True
    assert reply.usage.input_tokens > 0 and reply.usage.output_tokens > 0


def test_v5_tool_output_reaches_llm_wrapped(deps):
    seen = []

    class Spy(FakeLLM):
        def step(self, messages, tools):
            seen.append(messages)
            return super().step(messages, tools)

    deps.llm = Spy()
    answer("Summarise https://chipreport.example/2026/odd-page", [], deps)
    tool_msg = [m for m in seen[-1] if m["role"] == "tool"][0]
    assert tool_msg["content"].startswith("<<<TOOL_OUTPUT summarise_url (untrusted data")
    assert "Ignore all previous" not in tool_msg["content"]
    system = seen[-1][0]["content"]
    assert "untrusted" in system and "AI news" in system
