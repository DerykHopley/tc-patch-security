"""Settings from environment variables. See .env.example."""
import os
import pathlib
from dataclasses import dataclass

ROOT = pathlib.Path(__file__).resolve().parent.parent
FIXTURES = ROOT / "fixtures"


class ConfigError(RuntimeError):
    pass


@dataclass
class Settings:
    llm_provider: str = "fake"
    openrouter_api_key: str = ""
    openrouter_model: str = "openai/gpt-4o-mini"
    inbox_path: pathlib.Path = ROOT / "data" / "inbox.json"
    max_steps: int = 4

    @classmethod
    def from_env(cls) -> "Settings":
        s = cls(
            llm_provider=os.environ.get("LLM_PROVIDER", "fake").strip().lower(),
            openrouter_api_key=os.environ.get("OPENROUTER_API_KEY", "").strip(),
            openrouter_model=os.environ.get("OPENROUTER_MODEL", cls.openrouter_model).strip(),
            inbox_path=pathlib.Path(os.environ.get("INBOX_PATH", str(cls.inbox_path))),
            max_steps=int(os.environ.get("MAX_STEPS", "4")),
        )
        if not s.inbox_path.is_absolute():
            s.inbox_path = ROOT / s.inbox_path
        return s

    def check(self) -> None:
        """Fail at start-up with a clear message (L2)."""
        if self.llm_provider not in ("fake", "openrouter"):
            raise ConfigError(f"LLM_PROVIDER must be 'fake' or 'openrouter', not {self.llm_provider!r}.")
        if self.llm_provider == "openrouter" and not self.openrouter_api_key:
            raise ConfigError("LLM_PROVIDER=openrouter needs OPENROUTER_API_KEY. Set it in .env (see .env.example).")
